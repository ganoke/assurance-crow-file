
export interface NavItem {
  label: string;
  path: string;
}

export interface FeatureCardProps {
  icon: string;
  title: string;
  description: string;
}

export interface StepCardProps {
  step: number;
  icon: string;
  title: string;
  description: string;
}
