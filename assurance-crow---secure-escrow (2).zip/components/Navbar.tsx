
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { label: 'Home', path: '/' },
    { label: 'About', path: '/about' },
    { label: 'Privacy', path: '/privacy' },
    { label: 'Waitlist', path: '/waitlist' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-panel">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3 group">
          <div className="size-9 bg-primary/20 rounded-lg flex items-center justify-center text-primary border border-primary/30 group-hover:shadow-glow transition-all">
            <span className="material-symbols-outlined !text-[24px]">shield_lock</span>
          </div>
          <span className="text-white text-xl font-display font-bold tracking-tight">Assurance Crow</span>
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`text-sm font-medium transition-colors ${
                isActive(item.path) ? 'text-primary' : 'text-slate-400 hover:text-white'
              }`}
            >
              {item.label}
            </Link>
          ))}
          <Link to="/waitlist" className="bg-primary hover:bg-primary/90 hover:shadow-glow-sm transition-all text-white px-5 py-2.5 rounded-xl text-sm font-semibold">
            Get Started
          </Link>
        </div>

        {/* Mobile Toggle */}
        <button 
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="md:hidden text-white p-2"
        >
          <span className="material-symbols-outlined">{isMenuOpen ? 'close' : 'menu'}</span>
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-20 left-0 right-0 bg-background-dark/95 border-b border-white/10 p-6 flex flex-col gap-6 animate-in slide-in-from-top duration-300">
          {navItems.map((item) => (
            <Link
              key={item.path}
              onClick={() => setIsMenuOpen(false)}
              to={item.path}
              className={`text-lg font-medium ${
                isActive(item.path) ? 'text-primary' : 'text-slate-300'
              }`}
            >
              {item.label}
            </Link>
          ))}
          <Link 
            to="/waitlist" 
            onClick={() => setIsMenuOpen(false)}
            className="bg-primary text-white text-center py-3 rounded-xl font-bold"
          >
            Get Started
          </Link>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
