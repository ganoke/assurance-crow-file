
import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-surface-dark border-t border-white/5 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-3 text-white">
              <span className="material-symbols-outlined text-primary text-2xl">shield_lock</span>
              <h2 className="text-lg font-bold font-display">Assurance Crow</h2>
            </div>
            <p className="text-slate-400 text-sm">
              The world's most trusted payments platform. Protecting your high-value transactions since 2024.
            </p>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4">Product</h4>
            <ul className="flex flex-col gap-2 text-sm text-slate-400">
              <li><Link to="/" className="hover:text-primary transition-colors">How it works</Link></li>
              <li><a href="#" className="hover:text-primary transition-colors">Pricing</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">API</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Trust & Safety</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4">Company</h4>
            <ul className="flex flex-col gap-2 text-sm text-slate-400">
              <li><Link to="/about" className="hover:text-primary transition-colors">About Us</Link></li>
              <li><a href="#" className="hover:text-primary transition-colors">Careers</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Press</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Contact</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4">Legal</h4>
            <ul className="flex flex-col gap-2 text-sm text-slate-400">
              <li><Link to="/privacy" className="hover:text-primary transition-colors">Privacy Policy</Link></li>
              <li><a href="#" className="hover:text-primary transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Escrow Instructions</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-slate-500 text-xs">© 2024 Assurance Crow Inc. All rights reserved.</p>
          <div className="flex gap-4">
            <a className="text-slate-500 hover:text-white transition-colors" href="#"><i className="material-symbols-outlined text-lg">public</i></a>
            <a className="text-slate-500 hover:text-white transition-colors" href="#"><i className="material-symbols-outlined text-lg">mail</i></a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
