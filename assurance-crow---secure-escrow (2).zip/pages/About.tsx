
import React from 'react';
import { Link } from 'react-router-dom';

const About: React.FC = () => {
  return (
    <div className="w-full bg-background-dark text-slate-200 antialiased">
      {/* Hero Section */}
      <section className="relative px-6 pt-16 pb-24 md:pt-24 md:pb-32 overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="bg-[#1a1625]/60 backdrop-blur-sm border border-white/5 rounded-[40px] p-10 md:p-20 relative overflow-hidden">
            {/* Subtle purple glow */}
            <div className="absolute -top-24 -right-24 w-96 h-96 bg-primary/20 rounded-full blur-[120px] -z-10"></div>
            
            <div className="max-w-2xl">
              <span className="text-primary font-bold tracking-widest uppercase text-xs mb-6 block">
                About Assurance Crow
              </span>
              <h1 className="text-4xl md:text-6xl font-display font-bold text-white leading-[1.1] mb-8">
                Building trust into every transaction.
              </h1>
              <p className="text-slate-400 text-xl leading-relaxed">
                We are the bridge between uncertainty and guaranteed delivery in the digital economy.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Our Mission Section */}
      <section className="px-6 py-20">
        <div className="max-w-7xl mx-auto grid md:grid-cols-12 gap-12">
          <div className="md:col-span-8 flex gap-8">
            <div className="w-1.5 h-full bg-primary rounded-full shrink-0"></div>
            <div>
              <h2 className="text-3xl font-display font-bold text-white mb-8">Our Mission</h2>
              <p className="text-slate-400 text-lg leading-relaxed mb-6">
                Our mission is to make online transactions safer by removing uncertainty and protecting both buyers and sellers through secure escrow solutions. We envision a world where anyone can trade with confidence, regardless of distance or anonymity.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* What We Do Section */}
      <section className="px-6 py-20">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-display font-bold text-white mb-4">What We Do</h2>
          <p className="text-slate-500 mb-12">We provide a secure environment for your transactions by acting as an impartial third party.</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              { 
                icon: 'lock', 
                title: 'Secure Holdings', 
                desc: 'We hold funds securely in an insured escrow account until all transaction terms are mutually met.' 
              },
              { 
                icon: 'check_circle', 
                title: 'Fair Delivery', 
                desc: 'We ensure goods and services are delivered as promised before releasing payment to the seller.' 
              },
              { 
                icon: 'security', 
                title: 'Fraud Reduction', 
                desc: 'We actively reduce fraud and minimize payment disputes through rigorous verification processes.' 
              },
              { 
                icon: 'public', 
                title: 'Trust Enablement', 
                desc: 'We enable trust between strangers in a digital world, opening new markets and opportunities.' 
              }
            ].map((item, i) => (
              <div key={i} className="bg-[#131118] p-10 rounded-3xl border border-white/5 hover:border-primary/30 transition-all group">
                <div className="size-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center mb-8 group-hover:bg-primary group-hover:text-white transition-all">
                  <span className="material-symbols-outlined">{item.icon}</span>
                </div>
                <h3 className="text-white text-xl font-bold mb-4">{item.title}</h3>
                <p className="text-slate-400 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why We Exist Banner */}
      <section className="px-6 py-20">
        <div className="max-w-7xl mx-auto">
          <div className="relative bg-gradient-to-br from-primary via-primary/80 to-[#7c3aed] rounded-[40px] p-12 md:p-24 text-center overflow-hidden">
            {/* Mesh background effect */}
            <div className="absolute inset-0 opacity-20 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
            
            <div className="relative z-10 flex flex-col items-center gap-6">
              <div className="bg-white/10 backdrop-blur-md px-4 py-1.5 rounded-full border border-white/20 flex items-center gap-2">
                <span className="material-symbols-outlined !text-[14px] text-white">lightbulb</span>
                <span className="text-[10px] font-bold text-white uppercase tracking-widest">Our Purpose</span>
              </div>
              <h2 className="text-4xl md:text-6xl font-display font-bold text-white max-w-3xl">Why We Exist</h2>
              <p className="text-white/90 text-xl leading-relaxed max-w-2xl mx-auto">
                In a digital world where trust is fragile, Assurance Crow exists to be the neutral layer that guarantees honesty, delivery, and payment.
              </p>
              <Link to="/privacy" className="mt-8 bg-white text-primary hover:bg-slate-100 font-bold px-8 py-4 rounded-2xl transition-all shadow-xl">
                Learn About Our Security
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Brand Values Section */}
      <section className="px-6 py-24 bg-surface-dark/30">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Brand Values</h2>
          <p className="text-slate-500 mb-20 max-w-2xl mx-auto">The core principles that guide every decision we make and every line of code we write.</p>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { 
                icon: 'verified_user', 
                title: 'Trust First', 
                desc: 'We prioritize the safety of your funds above all else.' 
              },
              { 
                icon: 'visibility', 
                title: 'Transparency Always', 
                desc: 'No hidden fees, clear terms, and total visibility.' 
              },
              { 
                icon: 'shield', 
                title: 'Security by Design', 
                desc: 'Bank-grade encryption, compliance, and rigorous standards.' 
              },
              { 
                icon: 'balance', 
                title: 'Fairness for All', 
                desc: 'Impartial dispute resolution that protects both sides.' 
              }
            ].map((value, i) => (
              <div key={i} className="bg-[#131118] p-10 rounded-3xl border border-white/5 hover:border-primary/50 transition-all text-center flex flex-col items-center">
                <div className="size-16 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-8">
                  <span className="material-symbols-outlined !text-[32px]">{value.icon}</span>
                </div>
                <h3 className="text-white text-lg font-bold mb-4">{value.title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed">{value.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
