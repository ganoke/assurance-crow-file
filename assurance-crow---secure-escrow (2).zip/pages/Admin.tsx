
import React, { useEffect, useState } from 'react';
import { backendService, WaitlistEntry } from '../services/backend';

const Admin: React.FC = () => {
  const [entries, setEntries] = useState<WaitlistEntry[]>([]);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    setEntries(backendService.getWaitlist());
  }, []);

  const filteredEntries = entries.filter(e => 
    e.fullName.toLowerCase().includes(filter.toLowerCase()) || 
    e.email.toLowerCase().includes(filter.toLowerCase()) ||
    e.companyName.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-white">Waitlist Backend</h1>
          <p className="text-slate-500 mt-1">Total collected leads: {entries.length}</p>
        </div>
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="relative flex-grow md:w-64">
            <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-[20px]">search</span>
            <input 
              type="text" 
              placeholder="Search leads..." 
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="w-full bg-surface-dark border border-white/10 rounded-xl pl-10 pr-4 py-2 text-sm text-white focus:border-primary outline-none transition-all"
            />
          </div>
          <button 
            onClick={() => {
              if (window.confirm('Clear all waitlist data?')) {
                backendService.clearWaitlist();
                setEntries([]);
              }
            }}
            className="p-2.5 bg-red-500/10 text-red-400 border border-red-500/20 rounded-xl hover:bg-red-500/20 transition-all"
          >
            <span className="material-symbols-outlined !text-[20px]">delete</span>
          </button>
        </div>
      </div>

      <div className="bg-surface-dark border border-white/5 rounded-2xl overflow-hidden overflow-x-auto shadow-2xl">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-white/5 bg-white/5">
              <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">User</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Company</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Use Case</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Joined</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {filteredEntries.length > 0 ? filteredEntries.map((entry) => (
              <tr key={entry.id} className="hover:bg-white/[0.02] transition-colors">
                <td className="px-6 py-5">
                  <div className="font-bold text-white text-sm">{entry.fullName}</div>
                  <div className="text-slate-500 text-xs">{entry.email}</div>
                </td>
                <td className="px-6 py-5 text-sm text-slate-300 font-medium">
                  {entry.companyName}
                </td>
                <td className="px-6 py-5">
                  <p className="text-slate-400 text-xs line-clamp-1 max-w-[200px]" title={entry.useCase || 'No use case provided'}>
                    {entry.useCase || <span className="italic text-slate-600">No info</span>}
                  </p>
                </td>
                <td className="px-6 py-5 text-xs text-slate-500">
                  {new Date(entry.timestamp).toLocaleDateString()}
                </td>
                <td className="px-6 py-5 text-right">
                  <span className="inline-block px-2.5 py-1 rounded-full bg-primary/10 text-primary text-[10px] font-bold uppercase tracking-wider">
                    {entry.status}
                  </span>
                </td>
              </tr>
            )) : (
              <tr>
                <td colSpan={5} className="px-6 py-20 text-center text-slate-500">
                  <span className="material-symbols-outlined !text-[48px] block mb-4 opacity-20">inventory_2</span>
                  No entries found in the database.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Admin;
