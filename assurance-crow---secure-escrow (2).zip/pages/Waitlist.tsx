
import React, { useState } from 'react';
import { backendService } from '../services/backend';

const Waitlist: React.FC = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    companyName: '',
    useCase: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (error) setError(null);
  };

  const handleJoin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.email || !formData.fullName) return;
    
    setIsLoading(true);
    setError(null);

    try {
      await backendService.submitToWaitlist(formData);
      setIsSubmitted(true);
    } catch (err) {
      setError('Failed to join the waitlist. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-[70vh] flex items-center justify-center py-12 px-6 overflow-hidden relative">
      <div className="absolute top-[-20%] left-[30%] w-[600px] h-[600px] bg-primary/10 rounded-full blur-[140px] -z-10"></div>
      
      <div className="max-w-xl w-full">
        <div className="glass-panel p-8 md:p-12 rounded-3xl relative shadow-2xl border-t border-white/10">
          {!isSubmitted ? (
            <>
              <div className="text-center mb-10">
                <div className="size-16 bg-primary/20 rounded-2xl flex items-center justify-center text-primary mx-auto mb-6 border border-primary/30">
                  <span className="material-symbols-outlined !text-[32px]">mail</span>
                </div>
                <h1 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Join the Inner Circle</h1>
                <p className="text-slate-400">Be the first to get early access and exclusive discounted fees at launch. Secure your spot in the future of trusted payments.</p>
              </div>
              
              <form onSubmit={handleJoin} className="flex flex-col gap-5">
                {error && (
                  <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded-xl text-xs text-center">
                    {error}
                  </div>
                )}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Full Name</label>
                    <input 
                      type="text" 
                      name="fullName"
                      required
                      value={formData.fullName}
                      onChange={handleInputChange}
                      placeholder="John Doe"
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Email Address</label>
                    <input 
                      type="email" 
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="name@company.com"
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all text-sm"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Company Name</label>
                  <input 
                    type="text" 
                    name="companyName"
                    required
                    value={formData.companyName}
                    onChange={handleInputChange}
                    placeholder="Acme Corp"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all text-sm"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">How will you use Assurance Crow? (Optional)</label>
                  <textarea 
                    name="useCase"
                    value={formData.useCase}
                    onChange={handleInputChange}
                    placeholder="Tell us about your primary use case..."
                    rows={3}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all text-sm resize-none"
                  />
                </div>

                <button 
                  type="submit" 
                  disabled={isLoading}
                  className="bg-primary hover:bg-primary/90 text-white font-bold py-4 rounded-xl transition-all shadow-glow disabled:opacity-50 text-base flex items-center justify-center gap-2 mt-2"
                >
                  {isLoading ? (
                    <>
                      <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                      <span>Processing...</span>
                    </>
                  ) : (
                    <>
                      <span>Secure Your Spot</span>
                      <span className="material-symbols-outlined !text-[20px]">arrow_forward</span>
                    </>
                  )}
                </button>
              </form>
              
              <p className="mt-8 text-center text-[10px] text-slate-500">
                By joining, you agree to our <a href="#/privacy" className="text-primary hover:underline">Privacy Policy</a>. No spam, ever.
              </p>
            </>
          ) : (
            <div className="text-center py-10 animate-in zoom-in duration-500">
              <div className="size-24 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-8 text-green-400 border border-green-500/30">
                <span className="material-symbols-outlined !text-[48px]">check_circle</span>
              </div>
              <h2 className="text-3xl font-display font-bold text-white mb-4">You're on the list, {formData.fullName.split(' ')[0]}!</h2>
              <p className="text-slate-400 text-lg leading-relaxed">
                Thank you for your interest in Assurance Crow. We've reserved your spot for {formData.companyName}. We'll reach out shortly with instructions on how to activate your early-access account.
              </p>
              <button 
                onClick={() => {
                  setIsSubmitted(false);
                  setFormData({ fullName: '', email: '', companyName: '', useCase: '' });
                }}
                className="mt-8 text-primary font-bold hover:underline"
              >
                Join with another account
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Waitlist;
