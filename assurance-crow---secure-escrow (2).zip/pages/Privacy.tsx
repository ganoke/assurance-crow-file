
import React from 'react';

const Privacy: React.FC = () => {
  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      const offset = 100; // Account for fixed navbar
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="w-full bg-background-dark text-slate-200">
      {/* Page Title Section */}
      <section className="max-w-7xl mx-auto px-6 pt-12 lg:pt-20 pb-10">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold text-white mb-4">
          Privacy Policy
        </h1>
        <div className="flex items-center gap-2 text-slate-500 font-medium">
          <span className="material-symbols-outlined text-[20px]">calendar_today</span>
          <span>Last Updated: October 26, 2023</span>
        </div>
      </section>

      {/* Main Content Grid */}
      <section className="max-w-7xl mx-auto px-6 pb-24 grid lg:grid-cols-[300px_1fr] gap-12 items-start">
        
        {/* Sticky Sidebar - Table of Contents */}
        <aside className="hidden lg:block sticky top-28 bg-[#131118] border border-white/5 rounded-2xl p-6 shadow-xl">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-lg bg-primary/10 text-primary">
              <span className="material-symbols-outlined !text-[20px]">toc</span>
            </div>
            <h2 className="text-white font-bold text-sm tracking-tight">Table of Contents</h2>
          </div>
          <nav className="flex flex-col gap-1">
            {[
              { id: 'introduction', icon: 'info', label: 'Introduction' },
              { id: 'info-collect', icon: 'folder_open', label: 'Information We Collect' },
              { id: 'how-use', icon: 'settings', label: 'How We Use Information' },
              { id: 'data-protection', icon: 'shield', label: 'Data Protection' },
              { id: 'sharing', icon: 'share', label: 'Sharing of Information' },
              { id: 'rights', icon: 'gavel', label: 'Your Rights' },
              { id: 'contact', icon: 'mail', label: 'Contact' },
            ].map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                onClick={(e) => scrollToSection(e, item.id)}
                className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-400 hover:bg-primary/10 hover:text-white transition-all text-sm font-medium cursor-pointer"
              >
                <span className="material-symbols-outlined !text-[18px]">{item.icon}</span>
                {item.label}
              </a>
            ))}
          </nav>
        </aside>

        {/* Content Body */}
        <div className="flex flex-col gap-16">
          
          {/* Introduction */}
          <section id="introduction" className="scroll-mt-32">
            <div className="bg-[#131118] rounded-2xl p-8 md:p-10 border border-white/5">
              <h2 className="text-2xl font-display font-bold text-white mb-6">Introduction</h2>
              <p className="text-slate-400 leading-relaxed">
                Assurance Crow respects your privacy and is committed to protecting your personal data. This privacy policy will inform you as to how we look after your personal data when you visit our website (regardless of where you visit it from) and tell you about your privacy rights and how the law protects you. We believe in complete transparency when it comes to your financial security.
              </p>
            </div>
          </section>

          {/* 1. Information We Collect */}
          <section id="info-collect" className="scroll-mt-32">
            <div className="flex items-center gap-4 mb-8">
              <span className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-white font-bold">1</span>
              <h2 className="text-2xl font-display font-bold text-white">Information We Collect</h2>
            </div>
            <div className="flex flex-col gap-4">
              {[
                { 
                  icon: 'person', 
                  title: 'Personal Identification Information', 
                  desc: 'We may collect personal identification information from Users in a variety of ways, including, but not limited to, when Users visit our site, register on the site, place an order, fill out a form, and in connection with other activities, services, features or resources we make available on our Site. Users may be asked for, as appropriate, name, email address, mailing address, phone number, and government-issued identification for KYC purposes.' 
                },
                { 
                  icon: 'receipt_long', 
                  title: 'Transaction Details', 
                  desc: 'We collect information regarding the transactions you facilitate through our escrow service. This includes payment amounts, dates, times, sender and recipient details, and any dispute resolution history.' 
                },
                { 
                  icon: 'devices', 
                  title: 'Usage Data & Device Information', 
                  desc: 'We may collect information about how you access and use the Service. This includes IP address, browser type, pages visited, time spent on those pages, unique device identifiers and other diagnostic data.' 
                },
              ].map((item, idx) => (
                <details key={idx} className="group bg-[#131118] border border-white/5 rounded-2xl overflow-hidden" open={idx === 0}>
                  <summary className="flex cursor-pointer items-center justify-between p-6 md:px-8 hover:bg-white/5 transition-colors list-none">
                    <div className="flex items-center gap-4">
                      <span className="material-symbols-outlined text-primary">{item.icon}</span>
                      <h3 className="text-white font-bold">{item.title}</h3>
                    </div>
                    <span className="material-symbols-outlined text-slate-500 group-open:rotate-180 transition-transform">expand_more</span>
                  </summary>
                  <div className="px-6 pb-6 pt-2 md:px-8 md:pb-8 border-t border-white/5">
                    <p className="text-slate-400 text-sm leading-relaxed pt-4">
                      {item.desc}
                    </p>
                  </div>
                </details>
              ))}
            </div>
          </section>

          {/* 2. How We Use */}
          <section id="how-use" className="scroll-mt-32">
            <div className="flex items-center gap-4 mb-8">
              <span className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-white font-bold">2</span>
              <h2 className="text-2xl font-display font-bold text-white">How We Use Your Information</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { icon: 'handshake', title: 'Escrow Services', desc: 'To provide and maintain our escrow service, including monitoring the usage of our Service.' },
                { icon: 'payments', title: 'Process Transactions', desc: 'To manage your payments, fees, and charges, and collect and recover money owed to us.' },
                { icon: 'security_update_good', title: 'Platform Security', desc: 'To improve our platform security, prevent fraud, and detect unauthorized access.' },
                { icon: 'gavel', title: 'Legal Compliance', desc: 'To comply with legal obligations, court orders, or other legal processes and regulations.' },
              ].map((item, i) => (
                <div key={i} className="bg-[#131118] p-8 rounded-2xl border border-white/5 hover:border-primary/20 transition-all flex items-start gap-4">
                  <div className="p-3 rounded-xl bg-primary/10 text-primary">
                    <span className="material-symbols-outlined">{item.icon}</span>
                  </div>
                  <div>
                    <h4 className="text-white font-bold mb-2">{item.title}</h4>
                    <p className="text-slate-400 text-sm leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* 3. Data Protection */}
          <section id="data-protection" className="scroll-mt-32">
            <div className="flex items-center gap-4 mb-8">
              <span className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-white font-bold">3</span>
              <h2 className="text-2xl font-display font-bold text-white">Data Protection</h2>
            </div>
            <div className="bg-[#131118] border border-white/5 rounded-2xl p-8 md:p-12 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 blur-3xl -z-0"></div>
              <p className="text-slate-400 text-lg leading-relaxed mb-10 relative z-10">
                We implement industry-standard security measures to protect your personal information from unauthorized access, alteration, disclosure, or destruction. Security is at the core of our fintech infrastructure.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 relative z-10">
                {[
                  { icon: 'lock', label: '256-bit Encryption' },
                  { icon: 'admin_panel_settings', label: 'Access Control' },
                  { icon: 'eye_tracking', label: '24/7 Monitoring' },
                ].map((stat, i) => (
                  <div key={i} className="bg-background-dark/50 border border-white/5 p-6 rounded-xl flex flex-col items-center gap-3 text-center group hover:border-primary/50 transition-all">
                    <span className="material-symbols-outlined text-primary !text-[32px]">{stat.icon}</span>
                    <span className="text-white font-bold text-xs uppercase tracking-widest">{stat.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* 4. Sharing */}
          <section id="sharing" className="scroll-mt-32">
            <div className="flex items-center gap-4 mb-8">
              <span className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-white font-bold">4</span>
              <h2 className="text-2xl font-display font-bold text-white">Sharing of Information</h2>
            </div>
            <div className="bg-[#131118] border border-white/5 rounded-2xl p-8 md:p-10">
              <p className="text-white font-bold text-lg mb-6 leading-relaxed">
                We do not sell, trade, or rent Users personal identification information to others. <span className="text-slate-400 font-normal">We may share generic aggregated demographic information not linked to any personal identification information regarding visitors and users with our business partners.</span>
              </p>
              <div className="flex flex-col gap-4 pt-6 border-t border-white/5">
                {[
                  'Shared only for transaction completion',
                  'Shared for legal compliance and reporting',
                  'Shared for maintaining platform security',
                ].map((text, i) => (
                  <div key={i} className="flex items-center gap-3 text-sm text-slate-400">
                    <span className="material-symbols-outlined text-green-500 !text-[20px]">check_circle</span>
                    <span>{text}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* 5. Your Rights */}
          <section id="rights" className="scroll-mt-32">
            <div className="flex items-center gap-4 mb-8">
              <span className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-white font-bold">5</span>
              <h2 className="text-2xl font-display font-bold text-white">Your Rights</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                { icon: 'folder_shared', title: 'Access', desc: 'Request a copy of the personal data we hold about you.' },
                { icon: 'edit_document', title: 'Correction', desc: 'Request correction of the personal data that we hold about you.' },
                { icon: 'delete_forever', title: 'Deletion', desc: 'Request erasure of your personal data under certain conditions.' },
              ].map((item, i) => (
                <div key={i} className="bg-[#131118] p-8 rounded-2xl border border-white/5 flex flex-col items-center text-center gap-4 group hover:border-primary/30 transition-all">
                  <div className="size-14 rounded-2xl bg-primary/10 text-primary flex items-center justify-center group-hover:bg-primary group-hover:text-white transition-all">
                    <span className="material-symbols-outlined !text-[28px]">{item.icon}</span>
                  </div>
                  <h3 className="text-white font-bold text-lg">{item.title}</h3>
                  <p className="text-slate-500 text-xs leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </section>

          {/* Contact Section */}
          <section id="contact" className="scroll-mt-32">
            <div className="bg-[#131118] border border-white/5 rounded-3xl p-10 md:p-16 text-center relative overflow-hidden">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-primary/5 blur-[120px] -z-0"></div>
              <h2 className="text-3xl font-display font-bold text-white mb-4 relative z-10">Still have questions?</h2>
              <p className="text-slate-400 max-w-xl mx-auto mb-10 relative z-10">
                If you have any questions about this Privacy Policy, the practices of this site, or your dealings with this site, please contact us.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center relative z-10">
                <a 
                  href="mailto:privacy@assurancecrow.com"
                  className="bg-primary hover:bg-primary/90 text-white font-bold py-4 px-8 rounded-xl flex items-center justify-center gap-3 transition-all shadow-glow"
                >
                  <span className="material-symbols-outlined">mail</span>
                  privacy@assurancecrow.com
                </a>
                <button className="bg-white/5 hover:bg-white/10 text-white font-bold py-4 px-8 rounded-xl border border-white/10 flex items-center justify-center gap-3 transition-all">
                  <span className="material-symbols-outlined">help</span>
                  Help Center
                </button>
              </div>
            </div>
          </section>

        </div>
      </section>
    </div>
  );
};

export default Privacy;
