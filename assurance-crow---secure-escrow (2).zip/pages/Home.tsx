
import React from 'react';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center pt-12 lg:pt-0 overflow-hidden">
        <div className="absolute top-[-10%] left-[10%] w-[500px] h-[500px] bg-primary/20 rounded-full blur-[120px] -z-10 animate-pulse"></div>
        <div className="absolute bottom-[20%] right-[10%] w-[400px] h-[400px] bg-indigo-500/10 rounded-full blur-[100px] -z-10"></div>
        
        <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center">
          <div className="flex flex-col gap-6 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 w-fit mx-auto lg:mx-0">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
              <span className="text-[10px] font-bold text-primary-200 uppercase tracking-widest text-slate-400">Trusted by 10k+ businesses</span>
            </div>
            <h1 className="text-5xl lg:text-7xl font-display font-bold leading-[1.1] tracking-tight text-white">
              Secure Payments. <br/>
              <span className="text-gradient">Guaranteed Trust.</span>
            </h1>
            <p className="text-slate-400 text-lg leading-relaxed max-w-xl mx-auto lg:mx-0">
              Assurance Crow protects every transaction until both parties are satisfied. Buy, sell, and transact with complete peace of mind.
            </p>
            <div className="flex flex-wrap gap-4 justify-center lg:justify-start pt-4">
              <Link to="/waitlist" className="bg-primary hover:bg-primary/90 hover:shadow-glow transition-all text-white h-14 px-8 rounded-xl text-base font-bold flex items-center">
                Get Started
              </Link>
              <button className="glass-panel hover:bg-white/10 text-white h-14 px-8 rounded-xl text-base font-semibold transition-all border border-white/10 flex items-center gap-2 group">
                <span>How Escrow Works</span>
                <span className="material-symbols-outlined text-lg group-hover:translate-x-1 transition-transform">arrow_forward</span>
              </button>
            </div>
            <div className="flex items-center gap-6 justify-center lg:justify-start pt-6 text-sm text-slate-500">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-green-500 text-[20px]">check_circle</span>
                <span>Bank-grade Security</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-green-500 text-[20px]">check_circle</span>
                <span>Licensed & Regulated</span>
              </div>
            </div>
          </div>

          {/* Hero Image / Visual Element */}
          <div className="relative h-[450px] hidden lg:flex items-center justify-center">
             {/* Main Payment Card */}
             <div className="absolute z-20 w-[340px] glass-panel p-7 rounded-2xl shadow-2xl border-t border-white/20 scale-110">
                <div className="flex justify-between items-center mb-6">
                  <div className="flex items-center gap-3">
                    <div className="size-10 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400">
                      <span className="material-symbols-outlined">person</span>
                    </div>
                    <div>
                      <div className="text-white font-medium text-sm">Payment from Alex</div>
                      <div className="text-slate-400 text-[11px]">Web Design Project</div>
                    </div>
                  </div>
                  <span className="text-green-400 text-[10px] font-bold bg-green-400/10 px-2.5 py-1 rounded">SECURED</span>
                </div>
                <div className="text-3xl font-display font-bold text-white mb-2">$4,500.00</div>
                <div className="w-full bg-white/10 h-1.5 rounded-full mb-4 overflow-hidden">
                  <div className="bg-primary h-full w-[75%] rounded-full shadow-[0_0_10px_#5211d4]"></div>
                </div>
                <div className="flex justify-between text-[11px] text-slate-400 font-medium">
                  <span>Milestone 3/4</span>
                  <span>75%</span>
                </div>
             </div>
             {/* Secondary Elements */}
             <div className="absolute z-30 top-10 right-0 glass-panel px-4 py-3 rounded-xl flex items-center gap-3 animate-bounce shadow-xl">
               <span className="material-symbols-outlined text-green-400 bg-green-400/10 rounded-full p-1 !text-[18px]">verified_user</span>
               <span className="text-white text-xs font-bold">Funds Protected</span>
             </div>
             <div className="absolute z-30 bottom-10 left-0 glass-panel px-4 py-3 rounded-xl flex items-center gap-3 animate-pulse shadow-xl">
               <span className="material-symbols-outlined text-purple-400 bg-purple-400/10 rounded-full p-1 !text-[18px]">lock</span>
               <span className="text-white text-xs font-bold">Encrypted Data</span>
             </div>
          </div>
        </div>
      </section>

      {/* Trust Pillars */}
      <section className="py-20 bg-surface-dark/50 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
            {[
              { icon: 'shield_lock', title: 'Funds Held Securely', desc: 'Your money is kept in a regulated trust account until you\'re satisfied.' },
              { icon: 'gavel', title: 'Buyer & Seller Protection', desc: 'Neutral third-party protection ensuring fair play for both sides.' },
              { icon: 'bolt', title: 'Fast & Transparent', desc: 'Real-time status updates, quick setup, and clear milestone tracking.' },
              { icon: 'public', title: 'Global Commerce', desc: 'Optimized for international freelancers, domains, and marketplaces.' }
            ].map((pillar, i) => (
              <div key={i} className="group">
                <div className="size-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center mb-6 group-hover:bg-primary group-hover:text-white transition-all duration-300">
                  <span className="material-symbols-outlined !text-[28px]">{pillar.icon}</span>
                </div>
                <h3 className="text-white font-bold text-lg mb-2">{pillar.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{pillar.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <span className="text-primary font-bold tracking-widest uppercase text-xs">Process</span>
            <h2 className="text-4xl font-display font-bold text-white mt-4 mb-6">How It Works</h2>
            <p className="text-slate-400 max-w-xl mx-auto">Three simple steps to guarantee a safe transaction for everyone involved.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
            <div className="hidden md:block absolute top-[48px] left-[15%] right-[15%] h-[2px] bg-gradient-to-r from-transparent via-primary/30 to-transparent"></div>
            
            {[
              { step: 1, icon: 'description', title: 'Create an Agreement', desc: 'Buyer and Seller agree to terms. The Buyer submits payment to Assurance Crow.' },
              { step: 2, icon: 'lock_clock', title: 'Funds Secured', desc: 'Assurance Crow verifies the payment and notifies the Seller to deliver the goods.' },
              { step: 3, icon: 'check_circle', title: 'Release on Completion', desc: 'Once the Buyer approves the merchandise, funds are released to the Seller.' }
            ].map((item) => (
              <div key={item.step} className="flex flex-col items-center text-center relative z-10 group">
                <div className="size-24 rounded-2xl bg-surface-dark border border-white/10 flex items-center justify-center mb-8 shadow-glow-sm group-hover:border-primary/50 transition-all duration-500">
                  <span className="material-symbols-outlined !text-[40px] text-primary">{item.icon}</span>
                </div>
                <div className="glass-panel p-8 rounded-2xl w-full">
                  <span className="inline-block px-3 py-1 bg-white/5 border border-white/10 rounded-full text-[10px] font-bold text-white uppercase mb-4 tracking-widest">Step {item.step}</span>
                  <h3 className="text-xl font-bold text-white mb-3">{item.title}</h3>
                  <p className="text-slate-400 text-sm leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Feature Details Grid */}
      <section className="py-24 bg-surface-dark/40">
        <div className="max-w-7xl mx-auto px-6 flex flex-col lg:flex-row gap-16 items-start">
          <div className="lg:w-1/3 lg:sticky lg:top-32">
            <h2 className="text-4xl font-display font-bold text-white leading-tight mb-6">
              The Escrow Platform You Can Trust
            </h2>
            <p className="text-slate-400 text-lg mb-8">
              Why leading businesses and freelancers choose Assurance Crow for their critical transactions.
            </p>
            <Link to="/about" className="flex items-center gap-2 text-primary font-bold hover:gap-4 transition-all group">
              <span>Learn more about our security</span>
              <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
            </Link>
          </div>
          <div className="lg:w-2/3 grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              { icon: 'balance', title: 'Dispute Resolution', desc: 'Expert mediation team ready to step in if things don\'t go according to plan.' },
              { icon: 'receipt_long', title: 'Transparent Fees', desc: 'Clear pricing structure with no hidden costs. Calculate your fees before you start.' },
              { icon: 'encrypted', title: 'Secure Infrastructure', desc: 'Data is protected by 256-bit SSL encryption and state-of-the-art server security.' },
              { icon: 'account_balance', title: 'Regulatory Compliant', desc: 'Fully compliant with financial regulations and anti-money laundering laws.' }
            ].map((feat, i) => (
              <div key={i} className="bg-background-dark p-10 rounded-2xl border border-white/5 hover:border-primary/40 transition-all group">
                <div className="size-14 rounded-xl bg-surface-dark text-white flex items-center justify-center mb-8 group-hover:bg-primary group-hover:shadow-glow transition-all">
                  <span className="material-symbols-outlined !text-[32px]">{feat.icon}</span>
                </div>
                <h3 className="text-white text-xl font-bold mb-4">{feat.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{feat.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trade CTA */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-primary/5 -z-10"></div>
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-full bg-gradient-to-b from-primary/10 to-transparent blur-3xl -z-10"></div>
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-4xl md:text-6xl font-display font-bold text-white mb-8">
            Trade With Confidence. <br/>
            <span className="text-primary">Every Time.</span>
          </h2>
          <p className="text-slate-300 text-xl mb-12 max-w-2xl mx-auto leading-relaxed">
            Join thousands of businesses and individuals who trust Assurance Crow for their most important transactions.
          </p>
          <div className="flex flex-col sm:flex-row gap-5 justify-center">
            <Link to="/waitlist" className="bg-primary hover:bg-primary/90 hover:shadow-glow transition-all text-white h-16 px-10 rounded-2xl text-lg font-bold flex items-center justify-center min-w-[240px]">
              Create Your First Escrow
            </Link>
            <button className="glass-panel hover:bg-white/10 text-white h-16 px-10 rounded-2xl text-lg font-bold border border-white/10 transition-all min-w-[200px]">
              Contact Sales
            </button>
          </div>
          <p className="mt-8 text-sm text-slate-500">
            No credit card required for setup. <a href="#" className="text-primary hover:underline">Terms apply.</a>
          </p>
        </div>
      </section>
    </div>
  );
};

export default Home;
