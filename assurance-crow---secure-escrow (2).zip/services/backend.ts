
export interface WaitlistEntry {
  id: string;
  fullName: string;
  email: string;
  companyName: string;
  useCase: string;
  timestamp: string;
  status: 'pending' | 'reviewed' | 'accepted';
}

const STORAGE_KEY = 'assurance_crow_waitlist_db';

export const backendService = {
  // Save a new entry
  submitToWaitlist: async (data: Omit<WaitlistEntry, 'id' | 'timestamp' | 'status'>): Promise<WaitlistEntry> => {
    // Simulate network latency
    await new Promise(resolve => setTimeout(resolve, 1200));

    const entries = backendService.getWaitlist();
    const newEntry: WaitlistEntry = {
      ...data,
      id: Math.random().toString(36).substring(2, 11),
      timestamp: new Date().toISOString(),
      status: 'pending'
    };

    const updatedEntries = [newEntry, ...entries];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedEntries));
    
    return newEntry;
  },

  // Retrieve all entries
  getWaitlist: (): WaitlistEntry[] => {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  },

  // Clear database (for testing)
  clearWaitlist: () => {
    localStorage.removeItem(STORAGE_KEY);
  }
};
